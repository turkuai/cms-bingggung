# CMS

The purpose of this project is to create a simple CMS system. Using a visual editor users are able to create a website without the need of coding it. It's our job to make this possible for them.

https://bmwmilo.netlify.app/
https://turkuai.github.io/cms-bingggung/
